package com.error.girlai.store

import android.content.Context

object KeyStore {
    private const val PREF = "error_girl_ai_prefs"
    private const val KEY_API = "openai_api_key"

    fun saveApiKey(ctx: Context, key: String) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_API, key)
            .apply()
    }

    fun getApiKey(ctx: Context): String {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_API, "") ?: ""
    }
}
