package com.error.girlai.store

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ChatTurn(val role: String, val content: String)

object MemoryStore {
    private const val PREF = "error_girl_ai_prefs"
    private const val KEY_TURNS = "chat_turns"

    fun load(ctx: Context): MutableList<ChatTurn> {
        val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_TURNS, "[]") ?: "[]"
        val arr = JSONArray(s)
        val out = mutableListOf<ChatTurn>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(ChatTurn(o.getString("role"), o.getString("content")))
        }
        return out
    }

    fun save(ctx: Context, turns: List<ChatTurn>) {
        val arr = JSONArray()
        turns.forEach {
            val o = JSONObject()
            o.put("role", it.role)
            o.put("content", it.content)
            arr.put(o)
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TURNS, arr.toString())
            .apply()
    }

    fun append(ctx: Context, role: String, content: String, maxTurns: Int = 16): List<ChatTurn> {
        val turns = load(ctx)
        turns.add(ChatTurn(role, content))
        while (turns.size > maxTurns) turns.removeAt(0)
        save(ctx, turns)
        return turns
    }
}
