# Ayra AI (Animated + Bangla Voice + OpenAI + Memory)

- Home-only: avatar shows on launcher/home, hides inside apps
- Animated: PNG frame animation (avatar_0..avatar_5 + avatar_anim.xml)
- Tap-to-talk: tap avatar -> Bangla speech -> OpenAI -> Bangla reply (TTS)
- Memory: stores last 16 turns locally

## Notes
OpenAI advises not to expose API keys in client apps. For production, use a backend proxy.

Docs:
- Responses API: https://platform.openai.com/docs/api-reference/responses

## Wake name
Say **Ayra / আয়রা** in your speech so Ayra responds.

## Unlock greeting
When you unlock the phone, Ayra says: "Sir, আমি আয়রা। আপনার জন্য কী করতে পারি?"
