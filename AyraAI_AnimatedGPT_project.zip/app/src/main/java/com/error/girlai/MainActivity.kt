package com.error.girlai

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.error.girlai.overlay.OverlayService
import com.error.girlai.store.KeyStore

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val statusText = findViewById<TextView>(R.id.statusText)
        val apiInput = findViewById<EditText>(R.id.apiKeyInput)

        val btnOverlayPermission = findViewById<Button>(R.id.btnOverlayPermission)
        val btnUsagePermission = findViewById<Button>(R.id.btnUsagePermission)
        val btnSaveKey = findViewById<Button>(R.id.btnSaveKey)
        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnStop = findViewById<Button>(R.id.btnStop)

        fun usageGranted(): Boolean {
            return try {
                val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    appOps.unsafeCheckOpNoThrow(
                        AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(),
                        packageName
                    )
                } else {
                    @Suppress("DEPRECATION")
                    appOps.checkOpNoThrow(
                        AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(),
                        packageName
                    )
                }
                mode == AppOpsManager.MODE_ALLOWED
            } catch (_: Throwable) {
                false
            }
        }

        fun refreshStatus() {
            val overlayOk = Settings.canDrawOverlays(this)
            val usageOk = usageGranted()

            statusText.text = buildString {
                append("Overlay permission: ")
                append(if (overlayOk) "✅ Granted" else "❌ Not granted")
                append("\nUsage Access: ")
                append(if (usageOk) "✅ Granted" else "❌ Not granted")
                append("\n\nAvatar: Home-only + Animated (PNG frames).")
                append("\nVoice: Tap avatar to talk.")
                append("\nAI: OpenAI Responses API + Memory.")
            }

            btnStart.isEnabled = overlayOk
        }

        apiInput.setText(KeyStore.getApiKey(this))

        btnOverlayPermission.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        btnUsagePermission.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        btnSaveKey.setOnClickListener {
            KeyStore.saveApiKey(this, apiInput.text.toString().trim())
            refreshStatus()
        }

        btnStart.setOnClickListener {
            val i = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
        }

        btnStop.setOnClickListener {
            val i = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_STOP
            }
            startService(i)
        }

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        findViewById<Button>(R.id.btnStart).isEnabled = Settings.canDrawOverlays(this)
    }
}
